class Level {
    constructor(game) {
        this.game = game;
        this.levels = [level1, level2, level3];

    }

    levelGenerator(level) {
        level.forEach((row, rowIndex) => {
            row.forEach((brick, brickIndex) => {
                if (brick === 1) {
                    this.game.bricks.push(new Brick(this.game, this.game.gameWidth / (level1[0].length + 1) - 25 / level1[0].length + 100 * brickIndex, 50 + 40 * rowIndex));
                }
            })
        })
    }
}

const level1 = [
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1]
];

const level2 = [
    [1, 1, 1, 1, 1],
    [0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0]
];

const level3 = [
    [0, 0, 1, 0, 1],
    [1, 1, 1, 1, 1],
    [1, 1, 1, 0, 1]
];