//Get canvas
const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");

//Inıt canvas variables
const GAME_WIDTH = 700;
const GAME_HEIGHT = 400;

//Assign variables to canvas
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;

//Game instance
const game = new Game(GAME_WIDTH, GAME_HEIGHT);

//Game loop
let lastTime = 0;

function gameLoop(timestamp) {
    let deltaTime = timestamp - lastTime;
    lastTime = timestamp;

    game.update(deltaTime);
    game.draw(context);


    requestAnimationFrame(gameLoop);

}

requestAnimationFrame(gameLoop);