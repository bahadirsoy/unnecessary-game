class Game {
    constructor(gameWidth, gameHeight) {
        this.gameWidth = gameWidth;
        this.gameHeight = gameHeight;

        //Game state
        // 0-RUNNING 1-PAUSED 2-STARTMENU 3-GAMEOVER
        this.gameState = 2;

        this.currentLevel = 0;
        this.inputHandler = new InputHandler(this);

        this.sounds = new Sounds();

        

        this.init();

    }

    init() {
        this.paddle = new Paddle(this);
        this.ball = new Ball(this);

        this.bricks = [];
        this.level = new Level(this);
        
        this.level.levelGenerator(this.level.levels[this.currentLevel]);


        this.gameObjects = [this.paddle, this.ball, ...this.bricks];


    }

    update(deltaTime) {
        switch (this.gameState) {
            //running
            case 0:
                this.gameObjects.forEach((object) => {
                    object.update(deltaTime);
                })
                break;

                //paused
            case 1:
                return;
                break;

                //start menu
            case 2:
                return;
                break;

                //gameover
            case 3:
                return;
                break;

                //win
            case 4:
                return;
                break;
        }
    }

    draw(context) {
        context.clearRect(0, 0, this.gameWidth, this.gameHeight);

        switch (this.gameState) {

            //running
            case 0:
                this.gameObjects.forEach((object) => {
                    object.draw(context);
                })

                if (this.gameObjects.length === 2) {
                    
                    if(this.currentLevel+1===this.level.levels.length){
                        this.gameState=4;
                    }else{
                        this.currentLevel++;
                        this.init();
                    }
                    

                }
                break;

                //paused
            case 1:
                context.fillStyle = "gray";
                context.fillRect(0, 0, this.gameWidth, this.gameHeight);

                context.font = "50px Arial";
                context.fillStyle = "white";
                context.textAlign = "center";
                context.fillText("PAUSED", this.gameWidth / 2, this.gameHeight / 2);


                this.gameObjects.forEach((object) => {
                    object.draw(context);
                })

                break;

                //start menu
            case 2:
                context.fillStyle = "black";
                context.fillRect(0, 0, this.gameWidth, this.gameHeight);

                context.fillStyle = "white";
                context.font = "30px Arial";
                context.textAlign = "center";
                context.fillText("Press Spacebar to start the game", this.gameWidth / 2, this.gameHeight / 2);

                break;

                //gameover
            case 3:
                context.fillStyle = "white";
                context.fillRect(0, 0, this.gameWidth, this.gameHeight);

                context.fillStyle = "red";
                context.font = "50px Arial";
                context.textAlign = "center";
                context.fillText("GAME OVER", this.gameWidth / 2, this.gameHeight / 2 - 20);

                context.fillStyle = "black";
                context.font = "25px Arial";
                context.fillText("Press Spacebar to start a new game", this.gameWidth / 2, this.gameHeight / 2 + 20);

                break;

                //win
            case 4:
                context.fillStyle = "yellow";
                context.font = "80px Arial";
                context.textAlign = "center";
                context.fillText("YOU WIN!", this.gameWidth / 2, this.gameHeight / 2 - 20);

                break;
        }


    }

    gameOver() {
        this.gameState = 3;
        this.currentLevel = 0;
        this.init();
    }

    togglePause() {
        if (this.gameState === 1) {
            this.gameState = 0;
        } else if(this.gameState === 0) {
            this.gameState = 1;
        }
    }

}