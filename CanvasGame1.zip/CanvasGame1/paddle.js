class Paddle {
    constructor(game) {
        this.game = game;

        this.width = 100;
        this.height = 20;

        this.positionX = this.game.gameWidth / 2 - this.width / 2;
        this.positionY = this.game.gameHeight - this.height;

        this.movementSpeedX = 150;
        this.movementSpeedY = 40;
        this.speedX = 0;
        this.speedY = 0;
    }

    update(deltaTime) {
        this.positionX += this.speedX / deltaTime;
        this.positionY += this.speedY / deltaTime;

        //Check wall collisions
        this.checkLeftWallCollision();
        this.checkRightWallCollision();
        this.checkTopWallCollision();
        this.checkBottomWallCollision();

    }

    draw(context) {
        context.fillStyle="purple";
        context.fillRect(this.positionX, this.positionY, this.width, 3);
        context.fillStyle = "blue";
        context.fillRect(this.positionX, this.positionY+3, this.width, this.height-3);
    }

    checkLeftWallCollision(){
        if(this.positionX < 0){
            this.positionX = 0;
        }
    }

    checkRightWallCollision(){
        if(this.positionX > this.game.gameWidth - this.width){
            this.positionX = this.game.gameWidth - this.width;
        }
    }

    checkTopWallCollision(){
        if(this.positionY < 0){
            this.positionY = 0;
        }
    }

    checkBottomWallCollision(){
        if(this.positionY > this.game.gameHeight - this.height){
            this.positionY = this.game.gameHeight - this.height;
        }
    }

    
}