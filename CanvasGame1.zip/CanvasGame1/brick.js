class Brick{
    constructor(game,positionX,positionY){
        this.game=game;

        this.image=document.getElementById("brick");
        this.isHit = false;

        this.width=50;
        this.height=20;

        this.positionX=positionX;
        this.positionY=positionY;

    }

    update(deltaTime){

        //Check ball collision
        if(this.game.ball.checkBrickCollision(this.game.ball, this)){
            this.isHit=true;

            this.game.gameObjects.forEach((object, index) =>{
                if(object.isHit){
                    this.game.gameObjects.splice(index,1);
                }
            })
        }

    }

    draw(context){
        if(!this.isHit){
            context.drawImage(this.image,this.positionX,this.positionY,this.width,this.height);
        } 
    }

    

    
}