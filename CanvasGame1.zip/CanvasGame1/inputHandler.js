class InputHandler {
    constructor(game) {

        this.game = game;
        
        document.addEventListener("keydown", (e) => {
            
            switch (e.keyCode) {
                //left
                case 37:
                    this.game.paddle.speedX = -this.game.paddle.movementSpeedX;
                    break;

                //right
                case 39:
                    this.game.paddle.speedX = this.game.paddle.movementSpeedX;
                    break;

                /* //up
                case 38:
                    this.game.paddle.speedY = -this.game.paddle.movementSpeedY;
                    break; */

                //down
                case 40:
                    this.game.paddle.speedY = this.game.paddle.movementSpeedY;
                    break;

                    //esc
                case 27:
                    if(this.game.gameState===0 || this.game.gameState===1){
                        this.game.togglePause();
                    }
                    break;

                    //spacebar
                case 32:
                    if(this.game.gameState===2 || this.game.gameState===3){
                        this.game.gameState=0;
                    }
                    break;
            }
        });
        
        //Stop the paddle
        document.addEventListener("keyup", (e) => {
            switch (e.keyCode) {

                //left
                case 37:
                    if(this.game.paddle.speedX < 0){
                        this.game.paddle.speedX = 0;
                    }
                    break;

                //right
                case 39:
                    if(this.game.paddle.speedX > 0){
                        this.game.paddle.speedX = 0;
                    }
                    break;

                /* //up
                case 38:
                    if(this.game.paddle.speedY < 0){
                        this.game.paddle.speedY = 0;
                    }
                    break; */

                //down
                case 40:
                    if(this.game.paddle.speedY > 0){
                        this.game.paddle.speedY = 0;
                    }
                    break;
            }
        });
    }

}