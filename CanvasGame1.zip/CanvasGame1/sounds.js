class Sounds{
    constructor(){
        
    }

    hitPaddle(){
        var audio = new Audio('sounds/hitPaddle.mp3');
        audio.play();
    }

    hitBrick(){
        var audio = new Audio('sounds/hitBrick.mp3');
        audio.play();
    }
}