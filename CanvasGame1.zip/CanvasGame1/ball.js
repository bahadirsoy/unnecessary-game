class Ball {
    constructor(game) {
        this.game = game;

        this.width = 15;
        this.height = 15;

        this.positionX = 280;
        this.positionY = 300;

        this.movementSpeedX=100;
        this.movementSpeedY=100;
        this.speedX = 100;
        this.speedY = -100;

    }

    update(deltaTime) {
        this.positionX += this.speedX / deltaTime;
        this.positionY += this.speedY / deltaTime;

        //Check wall collisions
        this.checkLeftWallCollision();
        this.checkRightWallCollision();
        this.checkTopWallCollision();
        this.checkBottomWallCollision();

        //Check paddle collisions
        this.checkPaddleCollision();

    }

    draw(context) {
        context.fillStyle = "red";
        context.fillRect(this.positionX, this.positionY, this.width, this.height);
    }

    checkBrickCollision(ball, gameObject){

        if (((this.positionY + this.height >= gameObject.positionY))  &&
        !(this.positionY >= gameObject.positionY + gameObject.height) && 
            (((this.positionX + this.width >= gameObject.positionX && this.positionX <= gameObject.positionX) ||
                    (this.positionX <= gameObject.positionX + gameObject.width && this.positionX + this.width >= gameObject.positionX + gameObject.width)) ||
                (this.positionX >= gameObject.positionX && this.positionX + this.width <= gameObject.positionX + gameObject.width))) {
            this.speedY = -this.speedY;
            this.game.sounds.hitBrick();
            return true;
        }

    }

    checkPaddleCollision() {

        if (((this.positionY + this.height >= this.game.paddle.positionY)) &&
        !(this.positionY >= this.game.paddle.positionY + this.game.paddle.height) && 
            (((this.positionX + this.width >= this.game.paddle.positionX && this.positionX <= this.game.paddle.positionX) ||
                    (this.positionX <= this.game.paddle.positionX + this.game.paddle.width && this.positionX + this.width >= this.game.paddle.positionX + this.game.paddle.width)) ||
                (this.positionX >= this.game.paddle.positionX && this.positionX + this.width <= this.game.paddle.positionX + this.game.paddle.width))) {
            this.speedY = -this.movementSpeedY;
            this.game.sounds.hitPaddle();
        }

        
    }

    checkLeftWallCollision() {
        if (this.positionX < 0) {
            this.speedX = -this.speedX;
        }
    }

    checkRightWallCollision() {
        if (this.positionX > this.game.gameWidth - this.width) {
            this.speedX = -this.speedX;
        }
    }

    checkTopWallCollision() {
        if (this.positionY < 0) {
            this.speedY = -this.speedY;
        }
    }

    checkBottomWallCollision() {
        if (this.positionY > this.game.gameHeight - this.height) {
            this.speedY = -this.speedY;
            this.game.gameOver();
        }
    }

}